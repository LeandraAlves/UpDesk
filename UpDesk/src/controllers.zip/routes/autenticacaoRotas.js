const express = require('express');
const router = express.Router();
const autenticacaoController = require('../controllers/autenticacaoController');

router.get('/login', autenticacaoController.renderizarLogin);
router.post('/login', autenticacaoController.login);
router.get('/logout', autenticacaoController.logout);

module.exports = router;