const express = require('express');
const router = express.Router();
const autenticacaoController = require('../controllers/autenticacaoController');

// Rotas de login existentes
router.get('/login', autenticacaoController.renderizarLogin);
router.post('/login', autenticacaoController.login);

// --- ADICIONA ESTA ROTA DE LOGOUT ---
router.get('/logout', autenticacaoController.logout);

module.exports = router;