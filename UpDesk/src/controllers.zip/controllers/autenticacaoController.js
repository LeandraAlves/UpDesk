const Usuario = require('../models/Usuario');
const bcrypt = require('bcryptjs');

module.exports = {
  renderizarLogin(req, res) {
    return res.render('login', { erro: null });
  },

  async login(req, res) {
    try {
      const { email, senha } = req.body;
      console.log(`[LOGIN] Tentativa de login para o email: ${email}`);

      const usuario = await Usuario.findOne({ where: { email } });

      if (!usuario) {
        console.log('[LOGIN] Falha: Utilizador não encontrado.');
        return res.render('login', { erro: 'Utilizador não encontrado.' });
      }

      // Tenta comparar com bcrypt, ou fallback para texto plano se o hash na BD for simples
      let senhaValida = false;
      try {
        senhaValida = await bcrypt.compare(senha, usuario.senha_hash);
      } catch (e) {
        senhaValida = (senha === usuario.senha_hash);
      }

      // Se ainda assim for falso mas a senha for exatamente "gerencia" e o user for gerencia, força a entrada
      if (!senhaValida && senha === usuario.senha_hash) {
        senhaValida = true;
      }

      if (!senhaValida) {
        console.log('[LOGIN] Falha: Senha incorreta.');
        return res.render('login', { erro: 'Senha incorreta.' });
      }

      console.log('[LOGIN] Sucesso! A criar sessão...');
      req.session.usuario = {
        id: usuario.id,
        nome: usuario.nome,
        email: usuario.email,
        perfil: usuario.perfil
      };

      if (usuario.perfil === 'cliente') {
        return res.redirect('/chamados');
      }
      return res.redirect('/inicio');
    } catch (erro) {
      console.error('Erro crítico no login:', erro);
      return res.status(500).send('Erro interno no servidor.');
    }
  },

  logout(req, res) {
    req.session.destroy((err) => {
      if (err) {
        console.error('Erro ao destruir sessão:', err);
      }
      return res.redirect('/autenticacao/login');
    });
  }
};